﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura == 0)
            {
                errorProvider2.SetError(txtAltura, "Altura inválida!");
                txtAltura.Focus();
            }
            else
                errorProvider2.SetError(txtAltura, "");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            txtIMC.Text = imc.ToString("N2");

            if (imc < 18.5)
                MessageBox.Show("Sua classificação é:\nGRAU 0 - Magreza");
            if (imc >= 18.5 && imc <= 24.9)
                MessageBox.Show("Sua classificação é:\nGRAU 1 - Normal");
            if (imc >= 25 && imc <= 29.9)
                MessageBox.Show("Sua classificação é:\nGRAU 2 - Sobrepeso");
            if (imc >= 30 && imc <= 34.9)
                MessageBox.Show("Sua classificação é:\nGRAU 3 - Obesidade");
            if (imc >= 35)
                MessageBox.Show("Sua classificação é:\nGRAU 4 - Obesidade Grave");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Fechar a aplicação?", "Saída", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso) || peso == 0)
            {
                errorProvider1.SetError(txtPeso, "Peso inválido!");
                txtPeso.Focus();
            }
            else
                errorProvider1.SetError(txtPeso, "");
            
        }
    }
}
