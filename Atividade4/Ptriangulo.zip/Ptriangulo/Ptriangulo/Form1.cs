﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out valorB) || valorB <= 0)
            {
                errpValorB.SetError(txtValorB, "Valor inválido!");
                txtValorB.Focus();
            }
            else
            {
                errpValorB.SetError(txtValorB, "");
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorC.Text, out valorC) || valorC <= 0)
            {
                errpValorC.SetError(txtValorC, "Valor inválido!");
                txtValorC.Focus();
            }
            else
            {
                errpValorC.SetError(txtValorC, "");
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (valorA > valorB + valorC || valorA < Math.Abs(valorB - valorC))
            {
                MessageBox.Show("Valores inválidos! Impossível formar um triângulo.");
            }
            else if (valorB > valorA + valorC || valorB < Math.Abs(valorA - valorC))
            {
                MessageBox.Show("Valores inválidos! Impossível formar um triângulo.");
            }
            else if (valorC > valorA + valorB || valorC < Math.Abs(valorB - valorA))
            {
                MessageBox.Show("Valores inválidos! Impossível formar um triângulo.");
            }
            else if (valorA == valorB && valorA == valorC)
            {
                MessageBox.Show("Triângulo Equilátero");
            }
            else if (valorA == valorB || valorB == valorC)
            {
                MessageBox.Show("Triângulo Isósceles");
            }
            else
            {
                MessageBox.Show("Triângulo Escaleno");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Fechar a aplicação?", "Saída",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out valorA) || valorA <= 0)
            {
                errpValorA.SetError(txtValorA, "Valor inválido!");
                txtValorA.Focus();
            }
            else
                errpValorA.SetError(txtValorA, "");
        }
    }
}
