﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string entrada;
            int[,] matriz = new int[3, 5];
            int[] totalCurso = new int[3];
            totalCurso[0] = 0;
            totalCurso[1] = 0;
            totalCurso[2] = 0;
            int i, j;
            int totalGeral = 0;
            

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    matriz[i, j] = 0;
                }
            }



            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {


                    entrada = Interaction.InputBox("Digite o total de alunos do curso " + (i+1) + " do ano " + (j+1));

                    if (!int.TryParse(entrada, out matriz[i, j])) //tenta converter entrada para int e armazenar na matriz correpondente
                    { //se não der, ocorre:

                        MessageBox.Show("Dados inválidos! Insira apenas numeros inteiros");
                        j--; //retorna um para testar novamente após a correção do usuário
                    }
                    else
                    {
                        totalCurso[i] = totalCurso[i] + matriz[i, j];
                    }
                }
                totalGeral += totalCurso[i];
            }

            lstTotal.Items.Clear();

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    lstTotal.Items.Add("Total do Curso " + (i+1) + " do Ano " + (j+1) + ": " + matriz[i, j]);
                    
                }
                lstTotal.Items.Add("....................................");
                lstTotal.Items.Add("Total do Curso " + (i + 1) + ": " + totalCurso[i]);
            }
            lstTotal.Items.Add("....................................");
            lstTotal.Items.Add("Total Geral: " + totalGeral);
            



        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstTotal.Items.Clear ();
        }
    }
}
