﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int N = 2; 
            int Q = 10; 

            char[] gabarito = { 'B', 'C', 'A', 'B', 'E', 'A', 'C', 'D', 'B', 'A' }; 

            char[,] respostas = new char[N, Q];

            lstResultado.Items.Clear(); 

            for (int i = 0; i < N; i++) //aluno
            {
                MessageBox.Show($"Aluno {i + 1}: Digite as respostas das {Q} questões.");

                for (int j = 0; j < Q; j++) //respostas do aluno
                {
                    string entrada;
                    do
                    {
                        entrada = Interaction.InputBox($"Aluno {i + 1} - Questão {j + 1}\nDigite a resposta (A, B, C, D ou E):");
                        entrada = entrada.Trim().ToUpper();

                        if (entrada == "" || !"ABCDE".Contains(entrada))
                        {
                            MessageBox.Show("Entrada inválida! Use apenas A, B, C, D ou E.");
                        }

                    } while (entrada == "" || !"ABCDE".Contains(entrada));
                }
            }

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < Q; j++)
                {
                    char respostaAluno = respostas[i, j];
                    char respostaCerta = gabarito[j];

                    if (respostaAluno == respostaCerta)
                        lstResultado.Items.Add($"O aluno:{i + 1} acertou questão:{j + 1} era {respostaCerta} e escolheu {respostaAluno}");
                    else
                        lstResultado.Items.Add($"O aluno:{i + 1} errou questão:{j + 1} era {respostaCerta} e escolheu {respostaAluno}");
                }
            }
        }
    }
}
