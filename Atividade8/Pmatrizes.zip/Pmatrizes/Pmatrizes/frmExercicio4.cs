﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];  
            int[] tamanhos = new int[10];  
            bool contemNumero;
            contemNumero = false;
            string entrada;

            for (int i = 0; i < 10; i++)
            {
                do
                {
                    entrada = Interaction.InputBox("Digite o " + (i + 1) + "º  nome: ");
                    entrada = entrada.Trim();

                    if (entrada == "")
                    {
                        MessageBox.Show("Entrada inválida! O nome não pode ser vazio.");
                        continue;
                    }

                    contemNumero = entrada.Any(char.IsDigit);
                    if (contemNumero)
                    {
                        MessageBox.Show("Entrada inválida! Não use números.");
                    }

                } while ( entrada == "" || contemNumero);

                nomes[i] = entrada;

                string semEspacos = new string(entrada.Where(c => !char.IsWhiteSpace(c)).ToArray());
                tamanhos[i] = semEspacos.Length;
            }

            lstResultado.Items.Clear();
            for (int i = 0; i < 10; i++)
            {
                lstResultado.Items.Add($"O nome: {nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }
    }
}
