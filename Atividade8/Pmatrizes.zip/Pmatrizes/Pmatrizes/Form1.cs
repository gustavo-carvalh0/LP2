﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número: ", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i])) //tenta converter o auxiliar para int e armazenar no vetor[i] correpondente
                { //se não der, ocorre:
                    MessageBox.Show("Dados inválidos!");
                    i--; //retorna um para testar novamente após a correção do usuário
                }
            }
           
            Array.Reverse(vetor); //inverte o vetor
            auxiliar = ""; //limpa o auxiliar
            auxiliar = String.Join("\n", vetor); //une os elementos do array 'vetor' numa string contida em 'auxiliar'
            MessageBox.Show(auxiliar);

        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";

            ArrayList lista = new ArrayList(); //cria ArrayList
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Beatriz");
            lista.Add("Camila");
            lista.Add("João");
            lista.Add("Joana");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Otávio");

            foreach (string item in lista)
            {
                auxiliar += item + "\n"; //concatena tudo no auxiliar
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            int i, j;
            double[,] notas = new double[20, 3]; //declaração da matriz (linha, coluna)
            double[] medias = new double[20];
            string saida = "";

            for (i= 0; i < 20; i++)
            {
                medias[i] = 0;
                for (j = 0; j < 3; j++)
                {
                    string entrada = Interaction.InputBox("Digite a " + (j+1) + "º  nota do " + (i+1) + "º  aluno: ");
                    if (!double.TryParse(entrada, out notas[i,j]) || (notas[i, j]) < 0 || (notas[i, j]) > 10)
                    {
                        MessageBox.Show("Insira um valor válido! (Entre 0 e 10)");
                        j--;
                    }
                    else
                    {
                        medias[i] = medias[i] + notas[i, j];
                    }

                }

                medias[i] = medias[i] / 3;
                saida = saida + "Aluno " + (i+1) + ": média " + medias[i].ToString("F1") + "\n";
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj2 = new frmExercicio4();
                obj2.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio5 obj2 = new frmExercicio5();
                obj2.Show();
            }
        }
    }
}
