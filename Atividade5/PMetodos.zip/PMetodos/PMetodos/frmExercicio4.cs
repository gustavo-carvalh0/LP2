﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int comprimento = rchtxtFrase.Text.Length; //variavel com o tamanho da caixa de texto
            int contador = 0;
            int contaNum = 0;

            while(contador < comprimento) //enquanto o total for maior que o contador
            {
                if (Char.IsNumber(rchtxtFrase.Text[contador])) //checa se é numero
                {
                    contaNum++; //se for número, adiciona no contaNum
                }
                contador++; //adiciona o contador para não criar um loop
            }
            MessageBox.Show($"O texto tem {contaNum} números.");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i<rchtxtFrase.Text.Length; i++) //enquanto i for menor que o tamanho do texto, repete
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i])) //checa se há um espaço em branco
                {
                    MessageBox.Show($"A posição do 1º caracter em branco é: {i+1}"); //o $ é para colocar variaveis junto do texto
                    break; // tendo achado, finaliza o teste
                }

            }

        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach(var c in rchtxtFrase.Text) //para cada caracter do rchtxtFrase
            {
                if (Char.IsLetter(c)) //checa se é letra
                {
                    contaLetra++;
                }
            }
        }
    }
}
