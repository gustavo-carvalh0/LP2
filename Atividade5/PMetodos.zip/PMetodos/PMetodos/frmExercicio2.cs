﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            int resultado = String.Compare(palavra1, palavra2);

            if (resultado == 0)
            {
                MessageBox.Show("As palavras são iguais!");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes.");
            }
        }

        private void btnInserirMeio_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;
            string palavra2 = txtPalavra2.Text;

            int meio = palavra2.Length / 2;

            string primeiraParte = palavra2.Substring(0, meio);
            string segundaParte = palavra2.Substring(meio);

            string resultado = primeiraParte + palavra1 + segundaParte;

            txtPalavra2.Text = resultado;
        }

        private void btnInserirAst_Click(object sender, EventArgs e)
        {
            string texto = txtPalavra1.Text;

            int meio = texto.Length / 2;

            string resultado = texto.Insert(meio, "**");

            txtPalavra2.Text = resultado;
        }
    }
}
