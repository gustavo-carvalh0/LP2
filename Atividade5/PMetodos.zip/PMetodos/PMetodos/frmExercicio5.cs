﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            bool ok1 = int.TryParse(txtNumero1.Text, out int num1);
            bool ok2 = int.TryParse(txtNumero2.Text, out int num2);

            if (!ok1 || !ok2)
            {
                MessageBox.Show("Insira apenas números!");
                return;
            }

            if (num2 <= num1)
            {
                MessageBox.Show("O segundo número deve ser maior que o primeiro.");
                return;
            }

            Random r = new Random();
            int sorteado = r.Next(num1, num2 + 1);

            MessageBox.Show($"Número sorteado: {sorteado}");
        }
    }
}
